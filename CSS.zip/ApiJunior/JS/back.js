document.getElementById("entrar").addEventListener("click", function(event){
    event.preventDefault()
    let _data = {
        "usuario": $("#email").val(),
        "senha": $("#senha").val()
    }
    url = 'http://localhost:5000/login'
    fetch(url,
        {
            method: "POST",
            headers:{"Content-Type": "application/json"},
            body: JSON.stringify(_data)
        })
    .then(response => {
        return response.json()
    })
    .then(dado => {
        console.log(dado)  
    }).catch( err => {
        console.log(err)
    })    
});

