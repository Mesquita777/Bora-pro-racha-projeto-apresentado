function openAvailabilityModal(quadraName) {
  document.getElementById("quadraName").textContent = quadraName;
  document.getElementById("availabilityModal").style.display = "flex";
}

function closeAvailabilityModal() {
  document.getElementById("availabilityModal").style.display = "none";
}

function showAvailableTimes() {
  const date = document.getElementById("date").value;
  const availableTimesContainer = document.getElementById("availableTimes");

  if (!date) {
    availableTimesContainer.innerHTML = "<p>Por favor, selecione uma data.</p>";
    return;
  }

  const startHour = 6;
  const endHour = 22;
  let times = [];

  for (let hour = startHour; hour < endHour; hour++) {
    times.push(`${String(hour).padStart(2, "0")}:00`);
    times.push(`${String(hour).padStart(2, "0")}:30`);
  }

  const reservations =
    JSON.parse(localStorage.getItem("quadra_reservations")) || [];
  const quadraName = document.getElementById("quadraName").textContent;

  times = times.filter((time) => {
    return !reservations.some(
      (reservation) =>
        reservation.date === date &&
        reservation.time === time &&
        reservation.quadra === quadraName
    );
  });

  if (times.length === 0) {
    availableTimesContainer.innerHTML =
      "<p>Não há horários disponíveis para esta data.</p>";
  } else {
    availableTimesContainer.innerHTML = times
      .map(
        (time) => `
            <button onclick="confirmReservation('${quadraName}', '${date}', '${time}')">${time}</button>
        `
      )
      .join("");
  }
}

function confirmReservation(quadra, date, time) {
  const reservations =
    JSON.parse(localStorage.getItem("quadra_reservations")) || [];
  const reservationExists = reservations.some(
    (reservation) =>
      reservation.date === date &&
      reservation.time === time &&
      reservation.quadra === quadra
  );

  if (reservationExists) {
    alert(
      "Esse horário já está reservado para essa quadra. Por favor, escolha outro horário."
    );
    return;
  }

  reservations.push({ quadra, date, time });
  localStorage.setItem("quadra_reservations", JSON.stringify(reservations));

  closeAvailabilityModal();
  openConfirmationModal();
}

function openConfirmationModal() {
  document.getElementById("confirmationModal").style.display = "flex";
}

function closeConfirmationModal() {
  document.getElementById("confirmationModal").style.display = "none";
}

function openMyReservations() {
  const reservations =
    JSON.parse(localStorage.getItem("quadra_reservations")) || [];
  const myReservationsList = document.getElementById("myReservationsList");

  if (reservations.length === 0) {
    myReservationsList.innerHTML = "<p>Você não possui reservas.</p>";
  } else {
    myReservationsList.innerHTML = reservations
      .map(
        (reservation, index) => `
            <p>
                ${reservation.quadra} - ${reservation.date} às ${reservation.time}
                <button onclick="cancelReservation(${index})">Cancelar</button>
            </p>
        `
      )
      .join("");
  }

  document.getElementById("myReservationsModal").style.display = "flex";
}

function closeMyReservations() {
  document.getElementById("myReservationsModal").style.display = "none";
}

function cancelReservation(index) {
  let reservations =
    JSON.parse(localStorage.getItem("quadra_reservations")) || [];
  reservations.splice(index, 1);
  localStorage.setItem("quadra_reservations", JSON.stringify(reservations));
  openMyReservations();
}
