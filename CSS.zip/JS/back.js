document.getElementById("entrar").addEventListener("click", function(event){
    event.preventDefault()
    const formData = new FormData()
    formData.append('email', $("#email").val())
    formData.append('senha', $("#senha").val())

    url = 'http://localhost:8080/php/login/login.php'
    fetch(url,
        {
            method: "POST",
            body: formData
        })
    .then(response => {
        return response.json()
    })
    .then(dado => {
        localStorage.setItem("quadra_reservations",JSON.stringify(dado.reservas))
        localStorage.setItem("user_id",dado.user.id)
        localStorage.setItem("user_nome",dado.user.nome)
        localStorage.setItem("user_email",dado.user.email)
        localStorage.setItem("user_telefone",dado.user.telefone)
        localStorage.setItem("myReservationsList",JSON.stringify(dado.minhasreservas))
    }).catch( err => {
        console.log(err)
    })    
});

// async function addReserva(user,quadra,date,time){
//     const formData = new FormData()
//     formData.append('user', user)
//     formData.append('quadra', quadra)
//     formData.append('date', date)
//     formData.append('time', time)

//     url = 'http://localhost:8080/php/cadastros/reserva.php'
//     await fetch(url,
//         {
//             method: "POST",
//             body: formData
//         })
//     .then(response => {
//         return response.json()
//     })
//     .then(dado => {
//         //console.log(dado)
//         if(dado.error){
//             return false
            
//         }else{
//             return true
//         }
//     }).catch( err => {
//         console.log(err)
//     })   
// }

// function gellAllReservas(user){
//     url = 'http://localhost:8080/php/cadastros/reserva.php?user='+user
//     fetch(url,{method: "GET"})
//     .then(response => {
//         return response.json()
//     })
//     .then(dado => {
//         localStorage.setItem("quadra_reservations",JSON.stringify(dado.quadra_reservations))
//         localStorage.setItem("myReservationsList",JSON.stringify(dado.myReservationsList))
//         return
//     }).catch( err => {
//         console.log(err)
//     })   
// }

// function deleteReserva(id,user){
//     url = 'http://localhost:8080/php/cadastros/reserva.php?remover='+id
//     fetch(url,{method: "GET"})
//     .then(response => {
//         return response.json()
//     })
//     .then(dado => {
//         if(dado.error){
//             return false
//         }else{
//             return true 
//         }
//     }).catch( err => {
//         console.log(err)
//     })   
// }

