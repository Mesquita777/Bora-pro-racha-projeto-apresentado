<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $telefone = $_POST['telefone'];

    $stmt = $pdo->prepare("INSERT INTO usuarios (nome, sobrenome, email, senha, telefone) VALUES (?, ?, ?, ?, ?)");
    if ($stmt->execute([$nome, $sobrenome, $email, $senha, $telefone])) {
        echo "Usuário registrado com sucesso!";
    } else {
        echo "Erro ao registrar usuário.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
</head>
<body>
    <h2>Formulário de Cadastro</h2>
    <form method="POST" action="">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required>
        <br>
        <label for="sobrenome">Sobrenome:</label>
        <input type="text" name="sobrenome" required>
        <br>
        <label for="email">E-mail:</label>
        <input type="email" name="email" required>
        <br>
        <label for="senha">Senha:</label>
        <input type="password" name="senha" required>
        <br>
        <label for="telefone">Telefone:</label>
        <input type="text" name="telefone" required>
        <br>
        <input type="submit" value="Registrar">
    </form>
</body>
</html>
